import { createFileRoute } from "@tanstack/react-router";

import { LegalPage } from "@/components/site/LegalPage";

export const Route = createFileRoute("/terms-of-service")({
  head: () => ({
    meta: [
      { title: "Terms of Service | Hegxcorp" },
      {
        name: "description",
        content: "Terms governing use of the Hegxcorp website and digital services.",
      },
    ],
  }),
  component: TermsOfServicePage,
});

const sections = [
  {
    title: "Using this website",
    paragraphs: [
      "By using this website, you agree to these terms and to use the site lawfully. If you do not agree, please stop using the website.",
      "You must not attempt to disrupt the site, gain unauthorised access, introduce malicious code, or use site content in a misleading or unlawful way.",
    ],
  },
  {
    title: "Services and proposals",
    paragraphs: [
      "Website information describes our general capabilities and does not create a binding service agreement. Project scope, fees, timelines, responsibilities, and deliverables are confirmed in a separate proposal or contract.",
      "Any estimate or expected result is based on the information available at the time and is not a guarantee of a particular commercial outcome.",
    ],
  },
  {
    title: "Intellectual property",
    paragraphs: [
      "Unless stated otherwise, Hegxcorp owns or licenses the website design, text, graphics, code, branding, and other site content.",
      "You may view and share links to public pages for personal or business evaluation. Reproduction, resale, or creation of derivative material requires written permission.",
    ],
  },
  {
    title: "Third-party services and links",
    paragraphs: [
      "The website may link to third-party websites or rely on third-party tools. Hegxcorp does not control those services and is not responsible for their content, availability, or privacy practices.",
    ],
  },
  {
    title: "Availability and liability",
    paragraphs: [
      "We aim to keep the website accurate and available, but it may occasionally contain errors or be interrupted for maintenance, security, or reasons outside our control.",
      "To the extent permitted by law, Hegxcorp is not liable for indirect, incidental, or consequential loss arising solely from use of this public website.",
    ],
  },
  {
    title: "Changes and governing law",
    paragraphs: [
      "We may update these terms as the website and our services evolve. Continued use after an update means you accept the revised terms.",
      "These terms are governed by the laws applicable in India, subject to any mandatory rights that apply in your location.",
    ],
  },
];

function TermsOfServicePage() {
  return (
    <LegalPage
      eyebrow="Legal"
      title="Terms of Service"
      summary="These terms set the ground rules for using the Hegxcorp website and explain how website information relates to our professional services."
      sections={sections}
    />
  );
}
