import { createFileRoute, Link } from "@tanstack/react-router";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { getPublishedBlogs } from "@/lib/content/blogs";
import { blogs as defaultBlogs, type Blog } from "@/data/blogs";
import {
  Search as SearchIcon,
  ArrowRight,
  BookOpen,
  Sparkles,
  Mail,
  TrendingUp,
} from "lucide-react";
import ShapeGrid from "@/components/ShapeGrid";
import { motion, AnimatePresence } from "framer-motion";
import { useState, useMemo, useEffect } from "react";

export const Route = createFileRoute("/blog/")({
  head: () => ({
    meta: [
      { title: "Growth Lab Insights — SEO, Paid Media & CRO | Hegxcorp" },
      {
        name: "description",
        content:
          "Strategic breakdowns of organic search systems, campaign performance optimization, and high-converting website engineering.",
      },
      { property: "og:title", content: "Growth Lab Insights — SEO, Paid Media & CRO | Hegxcorp" },
      {
        property: "og:description",
        content:
          "Strategic breakdowns of organic search systems, campaign performance optimization, and high-converting website engineering.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://hegxcorp.com/blog" },
      { property: "og:image", content: "https://hegxcorp.com/cropped-hegxcorp-logo-new-web.webp" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Growth Lab Insights — SEO, Paid Media & CRO | Hegxcorp" },
      {
        name: "twitter:description",
        content:
          "Strategic breakdowns of organic search systems, campaign performance optimization, and high-converting website engineering.",
      },
      { name: "twitter:image", content: "https://hegxcorp.com/cropped-hegxcorp-logo-new-web.webp" },
    ],
    links: [{ rel: "canonical", href: "https://hegxcorp.com/blog" }],
  }),
  component: BlogPage,
});

function BlogPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedTag, setSelectedTag] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [subscribed, setSubscribed] = useState(false);
  const [emailInput, setEmailInput] = useState("");

  // Combined list: initialized with demo posts so the page renders instantly,
  // then supplements with any database published posts in background.
  const [allBlogs, setAllBlogs] = useState<Blog[]>(defaultBlogs);
  const [blogsLoaded, setBlogsLoaded] = useState(true);

  useEffect(() => {
    let active = true;
    getPublishedBlogs()
      .then((result) => {
        if (!active) return;
        if (result && result.length > 0) {
          setAllBlogs(result);
        }
      })
      .catch((loadError) => {
        console.error("Failed to load published blogs:", loadError);
      });
    return () => {
      active = false;
    };
  }, []);

  const articlesPerPage = 4;

  // Filter categories and tags
  const categories = useMemo(() => {
    return ["All", ...Array.from(new Set(allBlogs.map((a) => a.category)))];
  }, [allBlogs]);

  const popularTopics = [
    { label: "#TechnicalSEO", searchVal: "Technical SEO" },
    { label: "#CoreWebVitals", searchVal: "Core Web Vitals" },
    { label: "#PerformanceMax", searchVal: "Performance Max" },
    { label: "#GA4", searchVal: "GA4" },
    { label: "#LocalSEO", searchVal: "Local SEO" },
    { label: "#CRO", searchVal: "CRO" },
  ];

  // Filter logic
  const filteredArticles = useMemo(() => {
    return allBlogs.filter((article) => {
      const matchesSearch =
        article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        article.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
        article.content.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesCategory = selectedCategory === "All" || article.category === selectedCategory;

      const matchesTag =
        !selectedTag ||
        article.title.toLowerCase().includes(selectedTag.toLowerCase()) ||
        article.excerpt.toLowerCase().includes(selectedTag.toLowerCase()) ||
        article.content.toLowerCase().includes(selectedTag.toLowerCase());

      return matchesSearch && matchesCategory && matchesTag;
    });
  }, [allBlogs, searchQuery, selectedCategory, selectedTag]);

  // Featured article prioritizes the one marked as featured (newest first).
  // If none is featured, it falls back to "how-ai-search-reshapes-organic-traffic" or the first blog.
  const featuredArticle = useMemo(() => {
    const featuredList = allBlogs.filter((a) => a.featured);
    if (featuredList.length > 0) {
      return featuredList.sort(
        (left, right) =>
          new Date(right.publishedAt).getTime() - new Date(left.publishedAt).getTime(),
      )[0];
    }
    return allBlogs.find((a) => a.slug === "how-ai-search-reshapes-organic-traffic") || allBlogs[0];
  }, [allBlogs]);

  const mostReadArticles = useMemo(() => {
    if (!featuredArticle) return [];
    return allBlogs.filter((a) => a.slug !== featuredArticle.slug).slice(0, 4);
  }, [allBlogs, featuredArticle]);

  // Filtered feed (includes featured article)
  const feedArticles = useMemo(() => {
    return filteredArticles;
  }, [filteredArticles]);

  // Paginated articles
  const paginatedArticles = useMemo(() => {
    const startIndex = (currentPage - 1) * articlesPerPage;
    return feedArticles.slice(startIndex, startIndex + articlesPerPage);
  }, [feedArticles, currentPage, articlesPerPage]);

  const totalPages = Math.ceil(feedArticles.length / articlesPerPage) || 1;

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (emailInput.trim()) {
      setSubscribed(true);
      setEmailInput("");
      setTimeout(() => setSubscribed(false), 5000);
    }
  };

  const handleCategoryClick = (cat: string) => {
    setSelectedCategory(cat);
    setSelectedTag("");
    setCurrentPage(1);
  };

  const handleTagClick = (tagVal: string) => {
    if (selectedTag === tagVal) {
      setSelectedTag(""); // Toggle clear
    } else {
      setSelectedTag(tagVal);
      setSelectedCategory("All"); // Categories off when tags filter
    }
    setCurrentPage(1);
  };

  const scrollToLatestArticles = () => {
    window.requestAnimationFrame(() => {
      const target = document.getElementById("latest-articles");
      if (!target) return;

      const headerOffset = 110;
      const top = target.getBoundingClientRect().top + window.scrollY - headerOffset;
      window.scrollTo({ top, behavior: "smooth" });
    });
  };

  // Don't render the page (which assumes featuredArticle exists) until the
  // combined blog list has loaded from the database.
  if (!blogsLoaded || !featuredArticle) {
    return (
      <div className="min-h-screen bg-white flex flex-col">
        <Header />
        <div className="flex flex-1 items-center justify-center py-40 text-sm font-semibold text-[#6B7280]">
          Loading articles…
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white flex flex-col justify-between">
      <div>
        <Header />

        {/* ── SECTION 1: HERO SECTION ── */}
        <section
          className="relative overflow-hidden bg-white border-b border-[#EAEAEA] flex items-center "
          style={{ minHeight: "85vh", paddingTop: "80px", paddingBottom: "80px" }}
        >
          {/* Hexagon background motif */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 select-none"
            style={{ opacity: 0.2 }}
          >
            <ShapeGrid
              shape="hexagon"
              squareSize={38}
              borderColor="rgba(29,39,66,0.3)"
              hoverFillColor="transparent"
              hoverTrailAmount={0}
              staticMode={false}
              speed={0.2}
              className="w-full h-full"
            />
          </div>

          <div className="relative mx-auto grid w-full max-w-[1280px] gap-10 px-6 text-center lg:min-h-[500px] lg:grid-cols-[minmax(0,0.95fr)_minmax(360px,0.75fr)] lg:items-center lg:px-10 lg:text-left">
            <div className="mx-auto max-w-[720px] space-y-6 lg:mx-0">
              <span
                className="inline-flex items-center gap-1.5 rounded-full border border-[#EAEAEA] bg-[#FAFAF8] px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.15em] text-[#FC9C44] shadow-sm"
                style={{ fontFamily: "'Inter', sans-serif" }}
              >
                <Sparkles className="h-3 w-3 animate-pulse text-[#FC9C44]" />
                INSIGHTS
              </span>

              <h1
                className="font-bold text-[#232323] leading-[1.05] tracking-tight"
                style={{
                  fontFamily: "'Space Grotesk', sans-serif",
                  fontSize: "clamp(38px, 5vw, 68px)",
                }}
              >
                Insights From The Field
              </h1>

              <div
                className="mx-auto max-w-[680px] text-[#6B7280] lg:mx-0"
                style={{ fontFamily: "'Inter', sans-serif", fontSize: "clamp(15px, 1.1vw, 18px)" }}
              >
                <p className="leading-relaxed">
                  Data-driven marketing strategies. Explore in-depth articles on SEO, performance
                  marketing, website architecture, and conversion optimization to build digital
                  experiences that deliver measurable results.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row justify-center gap-3 sm:gap-4 pt-4 lg:justify-start">
                <button
                  onClick={() => {
                    document
                      .getElementById("latest-articles")
                      ?.scrollIntoView({ behavior: "smooth" });
                  }}
                  className="w-full sm:w-auto justify-center inline-flex items-center gap-2.5 rounded-full px-8 py-3.5 text-sm font-semibold text-white bg-[#FC9C44] hover:bg-[#2D3A5D] active:scale-98 transition-all cursor-pointer"
                  style={{ fontFamily: "'Inter', sans-serif" }}
                >
                  Browse Articles
                </button>
                <Link
                  to="/contact"
                  className="w-full sm:w-auto justify-center inline-flex items-center gap-2.5 rounded-full border border-[#EAEAEA] px-8 py-3.5 text-sm font-semibold text-[#1D2742] bg-[#FAFAF8] hover:bg-[#EAEAEA] active:scale-98 transition-all"
                  style={{ fontFamily: "'Inter', sans-serif" }}
                >
                  Contact Team
                </Link>
              </div>
            </div>

            <div className="mx-auto w-full max-w-[560px] lg:mx-0 lg:justify-self-end">
              <Link to="/blog/$slug" params={{ slug: featuredArticle.slug }} className="block">
                <motion.article className="overflow-hidden rounded-xl border border-[#EAEAEA] bg-white text-left shadow-[0_16px_36px_rgba(29,39,66,0.06)] transition-shadow duration-300 hover:shadow-[0_24px_48px_rgba(29,39,66,0.1)]">
                  <div className="group/image aspect-video overflow-hidden bg-[#FAFAF8]">
                    <img
                      src={featuredArticle.featuredImage}
                      alt={featuredArticle.title}
                      className="h-full w-full object-cover transition-transform duration-500 group-hover/image:scale-105"
                    />
                  </div>

                  <div className="group/text space-y-4 border-t border-[#EAEAEA] p-6">
                    <div className="flex flex-wrap items-center gap-3 text-[10px] font-bold uppercase tracking-wider text-[#9CA3AF]">
                      <span className="text-[#FC9C44]">Featured Article</span>
                      <span>{featuredArticle.category}</span>
                      <span>{featuredArticle.readTime}</span>
                    </div>

                    <h2
                      className="text-xl font-bold leading-tight text-[#1D2742] transition-colors duration-200 group-hover/text:text-[#FC9C44] md:text-2xl"
                      style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                    >
                      {featuredArticle.title}
                    </h2>

                    <p
                      className="line-clamp-2 text-sm leading-relaxed text-[#6B7280]"
                      style={{ fontFamily: "'Inter', sans-serif" }}
                    >
                      {featuredArticle.excerpt}
                    </p>

                    <div className="flex items-center gap-2 text-sm font-bold text-[#1D2742] transition-colors duration-200 group-hover/text:text-[#FC9C44]">
                      <span>Read Article</span>
                      <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover/text:translate-x-1" />
                    </div>
                  </div>
                </motion.article>
              </Link>
            </div>
          </div>
        </section>

        {/* ── SECTION 3: EDITORIAL GRID & DISCOVERY PANEL ── */}
        <section id="main-feed" className="py-20 bg-white">
          <div className="mx-auto max-w-[1280px] px-6 lg:px-10">
            <div className="grid lg:grid-cols-12 gap-12 lg:gap-16">
              {/* LEFT COLUMN: ARTICLES FEED (8 cols) */}
              <div id="latest-articles" className="scroll-mt-28 lg:col-span-8 space-y-12">
                <div className="flex items-center justify-between border-b border-[#EAEAEA] pb-5">
                  <h3
                    className="text-xl font-bold text-[#1D2742]"
                    style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                  >
                    {selectedCategory === "All" && !selectedTag
                      ? "Latest Articles"
                      : selectedCategory !== "All"
                        ? `Category: ${selectedCategory}`
                        : `Topic: #${selectedTag}`}
                  </h3>
                  <span className="text-xs font-semibold text-[#6B7280]">
                    Showing {feedArticles.length}{" "}
                    {feedArticles.length === 1 ? "article" : "articles"}
                  </span>
                </div>

                {/* Grid layout */}
                {paginatedArticles.length > 0 ? (
                  <div className="grid md:grid-cols-2 gap-8">
                    <AnimatePresence mode="popLayout">
                      {paginatedArticles.map((article) => (
                        <Link
                          key={article.slug}
                          to="/blog/$slug"
                          params={{ slug: article.slug }}
                          className="block"
                        >
                          <motion.div
                            whileHover="hover"
                            className="group flex flex-col h-full rounded-xl border border-[#EAEAEA] bg-white overflow-hidden shadow-sm hover:shadow-[0_16px_36px_rgba(29,39,66,0.06)] transition-all duration-300"
                            style={{ transformOrigin: "center" }}
                            variants={{
                              hover: { y: -4 },
                            }}
                          >
                            {/* Browser Mockup Header */}
                            <div className="flex items-center gap-1.5 px-4 py-2.5 bg-[#FAFAF8] border-b border-[#EAEAEA]">
                              <div className="flex gap-1">
                                <motion.span
                                  className="h-2 w-2 rounded-full bg-[#EAEAEA]"
                                  variants={{
                                    hover: {
                                      backgroundColor: "#FC9C44",
                                      transition: { delay: 0, duration: 0.15 },
                                    },
                                  }}
                                />
                                <motion.span
                                  className="h-2 w-2 rounded-full bg-[#EAEAEA]"
                                  variants={{
                                    hover: {
                                      backgroundColor: "#FC9C44",
                                      transition: { delay: 0.08, duration: 0.15 },
                                    },
                                  }}
                                />
                                <motion.span
                                  className="h-2 w-2 rounded-full bg-[#EAEAEA]"
                                  variants={{
                                    hover: {
                                      backgroundColor: "#FC9C44",
                                      transition: { delay: 0.16, duration: 0.15 },
                                    },
                                  }}
                                />
                              </div>
                              <div className="flex-1 max-w-[150px] mx-auto bg-white border border-[#EAEAEA] rounded py-0.5 px-2 text-[8px] text-[#9CA3AF] font-mono text-center select-none truncate">
                                text/blog
                              </div>
                            </div>

                            {/* Card Content Top (Simulated Visual Layout) */}
                            <div className="aspect-video overflow-hidden border-b border-[#EAEAEA] bg-[#FAFAF8]">
                              <img
                                src={article.previewImage || article.featuredImage}
                                alt={article.title}
                                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                              />
                            </div>

                            {/* Card Details Bottom */}
                            <div className="p-6 text-left flex-1 flex flex-col justify-between bg-white">
                              <div className="space-y-2">
                                <span className="text-[10px] font-bold uppercase tracking-wider text-[#FC9C44]">
                                  {article.category}
                                </span>
                                <h4
                                  className="text-base font-bold text-[#1D2742] tracking-tight group-hover:text-[#FC9C44] transition-colors duration-200 line-clamp-2 leading-snug"
                                  style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                                >
                                  {article.title}
                                </h4>
                                <p
                                  className="text-xs text-[#6B7280] leading-relaxed line-clamp-2"
                                  style={{ fontFamily: "'Inter', sans-serif" }}
                                >
                                  {article.excerpt}
                                </p>
                              </div>

                              <div className="pt-5 flex items-center gap-1.5 text-xs font-bold text-[#1D2742] group-hover:text-[#FC9C44] transition-colors duration-200 mt-auto">
                                <span>Read Article</span>
                                <motion.span
                                  variants={{
                                    hover: { x: 6 },
                                  }}
                                  transition={{ duration: 0.2 }}
                                >
                                  <ArrowRight className="h-3.5 w-3.5" />
                                </motion.span>
                              </div>
                            </div>
                          </motion.div>
                        </Link>
                      ))}
                    </AnimatePresence>
                  </div>
                ) : (
                  <div className="border border-dashed border-[#EAEAEA] rounded-xl py-20 text-center space-y-4">
                    <span className="flex h-12 w-12 items-center justify-center rounded-full bg-[#FFF4E8] text-[#FC9C44] mx-auto">
                      <BookOpen className="h-6 w-6" />
                    </span>
                    <div className="space-y-1">
                      <h4
                        className="text-base font-bold text-[#1D2742]"
                        style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                      >
                        No insights found
                      </h4>
                      <p
                        className="text-xs text-[#6B7280]"
                        style={{ fontFamily: "'Inter', sans-serif" }}
                      >
                        Try clearing search terms or modifying category selections.
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        setSearchQuery("");
                        setSelectedCategory("All");
                        setSelectedTag("");
                      }}
                      className="text-xs font-bold text-[#FC9C44] bg-[#FFF4E8] px-4 py-2 rounded-full hover:bg-[#FC9C44] hover:text-white transition-all cursor-pointer"
                    >
                      Clear Filters
                    </button>
                  </div>
                )}

                {/* ── PAGINATION ── */}
                {totalPages > 1 && (
                  <div className="flex items-center justify-center gap-2 border-t border-[#EAEAEA] pt-10 mt-6">
                    <button
                      disabled={currentPage === 1}
                      onClick={() => {
                        setCurrentPage((p) => Math.max(1, p - 1));
                        scrollToLatestArticles();
                      }}
                      className="px-4 py-2.5 text-xs font-bold text-[#1D2742] border border-[#EAEAEA] bg-[#FAFAF8] rounded-lg hover:bg-[#EAEAEA] disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                    >
                      ← Previous
                    </button>

                    <div className="flex items-center gap-1.5">
                      {Array.from({ length: totalPages }).map((_, i) => (
                        <button
                          key={i}
                          onClick={() => {
                            setCurrentPage(i + 1);
                            scrollToLatestArticles();
                          }}
                          className={`h-9 w-9 text-xs font-bold rounded-lg border transition-all ${
                            currentPage === i + 1
                              ? "bg-[#FC9C44] text-white border-[#FC9C44]"
                              : "bg-white text-[#6B7280] border-[#EAEAEA] hover:border-[#FC9C44]"
                          }`}
                        >
                          {i + 1}
                        </button>
                      ))}
                    </div>

                    <button
                      disabled={currentPage === totalPages}
                      onClick={() => {
                        setCurrentPage((p) => Math.min(totalPages, p + 1));
                        scrollToLatestArticles();
                      }}
                      className="px-4 py-2.5 text-xs font-bold text-[#1D2742] border border-[#EAEAEA] bg-[#FAFAF8] rounded-lg hover:bg-[#EAEAEA] disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                    >
                      Next →
                    </button>
                  </div>
                )}
              </div>

              {/* RIGHT COLUMN: STICKY DISCOVERY PANEL (4 cols) */}
              <div className="lg:col-span-4">
                <aside className="space-y-10 lg:sticky lg:top-[120px] lg:h-fit">
                  {/* Search Box */}
                  <div className="space-y-3 text-left">
                    <h4
                      className="text-xs font-bold text-[#1D2742] uppercase tracking-[0.1em]"
                      style={{ fontFamily: "'Inter', sans-serif" }}
                    >
                      Search Insights
                    </h4>
                    <div className="relative">
                      <input
                        type="text"
                        placeholder="Search insights..."
                        value={searchQuery}
                        onChange={(e) => {
                          setSearchQuery(e.target.value);
                          setCurrentPage(1);
                        }}
                        className="w-full rounded-lg border border-[#EAEAEA] bg-[#FAFAF8] py-3 pl-10 pr-4 text-xs text-[#232323] outline-none focus:border-[#FC9C44] focus:bg-white transition-all placeholder:text-[#9CA3AF]"
                      />
                      <SearchIcon className="absolute left-3.5 top-3 h-4 w-4 text-[#9CA3AF]" />
                    </div>
                  </div>

                  {/* Categories */}
                  <div className="space-y-4 text-left">
                    <h4
                      className="text-xs font-bold text-[#1D2742] uppercase tracking-[0.1em]"
                      style={{ fontFamily: "'Inter', sans-serif" }}
                    >
                      Categories
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {categories.map((cat) => (
                        <button
                          key={cat}
                          onClick={() => handleCategoryClick(cat)}
                          className={`px-4 py-2 text-xs font-semibold rounded-full border transition-all cursor-pointer ${
                            selectedCategory === cat
                              ? "bg-[#1D2742] text-white border-[#1D2742]"
                              : "bg-[#FAFAF8] text-[#6B7280] border-[#EAEAEA] hover:border-[#FC9C44]/30 hover:bg-[#FFF4E8]/20"
                          }`}
                        >
                          {cat}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Popular Topics */}
                  <div className="space-y-4 text-left">
                    <h4
                      className="text-xs font-bold text-[#1D2742] uppercase tracking-[0.1em]"
                      style={{ fontFamily: "'Inter', sans-serif" }}
                    >
                      Popular Topics
                    </h4>
                    <div className="flex flex-wrap gap-2.5">
                      {popularTopics.map((topic) => (
                        <button
                          key={topic.label}
                          onClick={() => handleTagClick(topic.searchVal)}
                          className={`px-3 py-1.5 text-[11px] font-semibold rounded-lg border transition-all cursor-pointer ${
                            selectedTag === topic.searchVal
                              ? "bg-[#FC9C44] text-white border-[#FC9C44]"
                              : "bg-white text-[#4A5568] border-[#EAEAEA] hover:border-[#FC9C44]/20 hover:bg-[#FAFAF8]"
                          }`}
                        >
                          {topic.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Newsletter Signup Card */}
                  <div className="rounded-xl border border-[#EAEAEA] bg-[#FAFAF8] p-6 text-left relative overflow-hidden">
                    {/* Small visual decoration */}
                    <div className="absolute -top-12 -right-12 h-24 w-24 rounded-full bg-[#FFF4E8]/40 blur-xl" />

                    <div className="relative z-10 space-y-4">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#FFF4E8] text-[#FC9C44]">
                        <Mail className="h-5 w-5" />
                      </div>

                      <div className="space-y-1">
                        <h4
                          className="text-base font-bold text-[#1D2742]"
                          style={{ fontFamily: "'Space Grotesk', sans-serif" }}
                        >
                          Get Weekly Growth Insights
                        </h4>
                        <p
                          className="text-xs text-[#6B7280] leading-relaxed"
                          style={{ fontFamily: "'Inter', sans-serif" }}
                        >
                          Get notified when new guides, frameworks, and digital systems analysis
                          papers go live.
                        </p>
                      </div>

                      <form onSubmit={handleSubscribe} className="space-y-2 pt-1">
                        <input
                          type="email"
                          required
                          placeholder="business@email.com"
                          value={emailInput}
                          onChange={(e) => setEmailInput(e.target.value)}
                          className="w-full rounded-lg border border-[#EAEAEA] bg-white px-3 py-2.5 text-xs text-[#232323] outline-none focus:border-[#FC9C44] transition-all placeholder:text-[#9CA3AF]"
                        />
                        <button
                          type="submit"
                          className="w-full rounded-lg bg-[#FC9C44] py-2.5 text-xs font-semibold text-white hover:bg-[#E88C35] transition-all cursor-pointer"
                        >
                          Subscribe
                        </button>
                      </form>

                      <AnimatePresence>
                        {subscribed && (
                          <motion.div
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            exit={{ opacity: 0 }}
                            className="text-[10px] font-bold text-emerald-600 bg-emerald-50 border border-emerald-100 rounded-lg p-2.5 text-center mt-2"
                          >
                            ✓ Subscribed! Check your inbox soon.
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  </div>
                </aside>
              </div>
            </div>
          </div>
        </section>
      </div>
      <section className="bg-white px-6 py-20 sm:py-24 lg:px-10">
        <div className="relative mx-auto max-w-[1200px] overflow-hidden rounded-[2rem] bg-[#06133D] px-6 py-14 text-center text-white sm:px-12 sm:py-16">
          <div className="absolute -left-20 -top-20 h-64 w-64 rounded-full bg-[#FC9C44]/20 blur-3xl" />
          <div className="absolute -bottom-32 -right-24 h-72 w-72 rounded-full bg-[#3A65FF]/20 blur-3xl" />
          <div className="relative mx-auto max-w-3xl">
            <p className="text-sm font-bold uppercase tracking-[0.2em] text-[#FFB36E]">
              Keep Learning With Hegxcorp
            </p>
            <h2 className="mt-4 text-3xl font-bold leading-tight sm:text-4xl lg:text-5xl">
              Want sharper ideas for your next stage of growth?
            </h2>
            <p className="mx-auto mt-5 max-w-2xl text-base leading-8 text-white/70">
              Read more practical insights from our team, or talk with us about turning what you
              learn into a focused digital plan.
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-4">
              <Link
                to="/free-growth-audit"
                className="inline-flex items-center gap-2 rounded-full bg-[#FC9C44] px-6 py-3.5 text-sm font-semibold text-[#06133D] transition hover:bg-[#ffad63]"
              >
                Get a Free Growth Audit <ArrowRight className="h-4 w-4" />
              </Link>
              <Link
                to="/contact"
                className="inline-flex items-center rounded-full border border-white/25 px-6 py-3.5 text-sm font-semibold text-white transition hover:bg-white/10"
              >
                Contact Us
              </Link>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </div>
  );
}
