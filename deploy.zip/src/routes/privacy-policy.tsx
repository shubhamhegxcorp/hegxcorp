import { createFileRoute } from "@tanstack/react-router";

import { LegalPage } from "@/components/site/LegalPage";

export const Route = createFileRoute("/privacy-policy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy | Hegxcorp" },
      {
        name: "description",
        content: "Learn how Hegxcorp collects, uses, protects, and manages personal information.",
      },
    ],
  }),
  component: PrivacyPolicyPage,
});

const sections = [
  {
    title: "Information we collect",
    paragraphs: [
      "We may collect information you provide through contact forms, growth-audit requests, project enquiries, and direct communication with our team.",
    ],
    items: [
      "Contact details such as your name, email address, and phone number.",
      "Business information such as company name, website, goals, budget, and project requirements.",
      "Technical and usage information such as browser type, device information, pages visited, and approximate location.",
    ],
  },
  {
    title: "How we use information",
    paragraphs: [
      "We use collected information to respond to enquiries, provide requested services, improve our website, maintain security, and communicate about relevant Hegxcorp services.",
      "We do not sell personal information. We only share it with service providers when needed to operate our business or when required by law.",
    ],
  },
  {
    title: "Cookies and analytics",
    paragraphs: [
      "Our website may use essential cookies and analytics technologies to keep the site functional, understand performance, and improve the visitor experience.",
      "You can control non-essential cookies through your browser settings. Blocking some cookies may affect parts of the website.",
    ],
  },
  {
    title: "Data retention and security",
    paragraphs: [
      "We retain information only for as long as reasonably necessary for the purpose it was collected, including legal, accounting, and operational requirements.",
      "We use reasonable technical and organisational measures to protect information, but no internet transmission or storage system can be guaranteed completely secure.",
    ],
  },
  {
    title: "Your choices and rights",
    paragraphs: [
      "Depending on applicable law, you may ask to access, correct, delete, or restrict the use of your personal information, or withdraw consent where processing is based on consent.",
      "Send requests to hegxcorp@gmail.com. We may need to verify your identity before completing a request.",
    ],
  },
  {
    title: "Updates to this policy",
    paragraphs: [
      "We may update this policy when our services, technology, or legal obligations change. The latest version will always appear on this page with its updated date.",
    ],
  },
];

function PrivacyPolicyPage() {
  return (
    <LegalPage
      eyebrow="Legal"
      title="Privacy Policy"
      summary="This policy explains what information Hegxcorp collects, why we use it, and the choices available to you."
      sections={sections}
    />
  );
}
